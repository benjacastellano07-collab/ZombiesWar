ZOMBIE WAR - Proyecto Android inicial
========================================

Este paquete contiene:
- Un juego web pixel-art jugable (app/src/main/assets/index.html).
- Un proyecto Android que lo abre en pantalla completa.
- Un flujo de GitHub Actions para compilar el APK automáticamente.

IMPORTANTE:
Este paquete es el PROYECTO FUENTE, no un APK ya compilado.
La compilación Android necesita Gradle/Android SDK. El workflow incluido puede
hacerla en GitHub Actions cuando el proyecto esté en un repositorio.

Para probar el juego sin compilar:
1. Extraé el ZIP.
2. Abrí app/src/main/assets/index.html con Chrome en tu Android.

Para generar el APK:
1. Subí el contenido de esta carpeta a un repositorio de GitHub.
2. Abrí la pestaña Actions.
3. Ejecutá "Build Zombie War APK" (o esperá que se ejecute al subir cambios).
4. Abrí la ejecución terminada y descargá el artefacto "ZombieWar-debug-apk".

Controles:
- Pad izquierdo: moverse.
- Botón DISPARAR: disparo automático hacia el enemigo más cercano.
- REINICIAR: empezar otra partida.

El juego es una versión inicial arcade, sin contenido gráfico explícito.
